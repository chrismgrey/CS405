// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits> // Added so extra input can be safely cleared from the input stream.
#include <string> // Added to explicitly support the std::string data type used below.

// Reads input safely and returns false to notify the calling function if the input is too long.
// Static keeps this helper function limited to this source file.
static bool readUserInput(char* buffer, std::streamsize bufferSize)
{
	std::cin.getline(buffer, bufferSize);

	// If the buffer limit is reached, clear the error and remove the remaining input.
	if (std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		return false;
	}

	return true;
}

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  
  // Use the buffer's actual size so input cannot be written past its boundary.
  if (!readUserInput(user_input, sizeof(user_input)))
  {
	  // Notify the user that oversized input was detected and safely blocked.
	  std::cout << "Input too long. Buffer overflow prevented." << std::endl;
	  std::cout << "Account Number = " << account_number << std::endl;
	  return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
