// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception> // Provides the std::exception base class.
#include <stdexcept> // Provides standard exception types.

// Custom exception for application-specific errors.
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application logic exception.";
    }
};

bool do_even_more_custom_application_logic()
{
    // Simulate a standard exception for testing.
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Even More Custom Application Logic failed.");
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Catch standard exceptions so processing can continue.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "Standard exception caught: " << e.what() << std::endl;
    }

    // Throw a custom exception for main() to handle.
    throw CustomException();    
}

float divide(float num, float den)
{
    // Prevent invalid division by zero.
    if (den == 0.0f)
    {
        throw std::domain_error("Cannot divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    // Catch only the divide-by-zero exception thrown by divide().
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& e)
    {
        std::cout << "Division exception caught: " << e.what() << std::endl;
    }
}

int main()
{
    // Catch exceptions from most specific to most general.
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        std::cout << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << "Standard exception caught in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Unknown exception caught." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu